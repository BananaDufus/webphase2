<html>
<head>
<title>Mobigin</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">



</head>
<body>
<div class="container">
      <div class="row">
        <div class="col-lg-9">
          <a href="http://localhost/phase2/HomePage.php"><img src="logo.png" alt="Logo"></a>
        </div>
        <div class="col-lg-3" style="margin-top: 5%;">
          <a  href="https://twitter.com/"><img src="1.png"  ></a>
          <a  href="https://www.facebook.com/"><img src="2.png"  ></a>
          <a  href="https://www.instagram.com/"><img src="3.png"></a>
          <a  href="https://www.youtube.com/"><img src="4.png"></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-light" style="background-color:black">
    <a href="http://localhost/phase2/HomePage.php">Home</a>
    <a href="http://localhost/phase2/AboutUs.php">About US</a>
    <a href="http://localhost/phase2/Products.php">Products</a>
    <a href="http://localhost/phase2/ContactUs.php">Contact Us</a>

  </nav>
  <h1><center>MOBIGIN</center></h1>



<div style="text-align: center;">
  
    <figure class="figure" >
        <a href="file:///G:/pro/p3.html"><img src="p1.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Aspor A323</center></b></figcaption></a>
    
      </figure>
    <figure class="figure"  >
        <a href="file:///G:/pro/p4.html"><img src="p2.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Car DVR Mirror DUAL</center></b></figcaption></a>
    </figure>

    <figure class="figure" >
        <a href="file:///G:/pro/p2.html"><img src="p3.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Laptop E-Table Portable</center></b></figcaption></a>
        </figure>
     
      </br>
    
    <figure class="figure" >
        <a href="file:///G:/pro/p1.html"><img src="p4.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Latest IP Wireless 360 Camera </center></b></figcaption></a>
    </figure>
  
    <figure class="figure" >
        <a href="file:///G:/pro/p5.html"><img src="p5.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Action Sports Camera WiFi 4K</center></b></figcaption></a>
    </figure>


    <figure class="figure" style="" >
       <a href="file:///G:/pro/p6.html"> <img src="p6.jpg" class="figure-img img-fluid rounded" alt="...">
        <figcaption class="figure-caption"><b><center>Super Bright Switch</center></b></figcaption></a>
      
    </figure></div>

<!-------------------------------------------Footer----------------------------------------------------->
   
  <!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left mt-3 pb-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">MOBIGIN</h6>
        <p>Mobigin is the best place where you can buy the best mobile accessories.</p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Products</h6>
        <p>
          <a href="#!">Handfrees</a>
        </p>
        <p>
          <a href="#!">Chargers</a>
        </p>
        <p>
          <a href="#!">Datacables</a>
        </p>
        <p>
          <a href="#!">Gaming Remotes</a>
        </p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Useful links</h6>
        <p>
          <a href="#!">Your Account</a>
        </p>
        <p>
          <a href="#!">Become an Affiliate</a>
        </p>
        <p>
          <a href="#!">Shipping Rates</a>
        </p>
        <p>
          <a href="#!">Help</a>
        </p>
      </div>

      <!-- Grid column -->
      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Contact</h6>
        <p>
          <i class="fas fa-home mr-3"></i>Ghari shahu lahore</p>
        <p>
          <i class="fas fa-envelope mr-3"></i> buland1261khan@gmail.com</p>
        <p>
          <i class="fas fa-phone mr-3"></i> +92 314 424 4289</p>
        <p>
          <i class="fas fa-print mr-3"></i> +92 314 424 4289</p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Footer links -->

    <hr>

    <!-- Grid row -->
    <div class="row d-flex align-items-center">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left">© 2020 Copyright:
          <a href="https://facebook.com/">
            <strong> facebook
            </strong>
          </a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->
</body></html>