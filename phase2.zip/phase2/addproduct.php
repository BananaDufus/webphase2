<html>
<head>
<title>Mobigin</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">



</head>
<body>
    <div class="container">
      <div class="row">
        <div class="col-lg-9">
          <a href="http://localhost/phase2/HomePage.php"><img src="logo.png" alt="Logo"></a>
        </div>
        <div class="col-lg-3" style="margin-top: 5%;">
          <a  href="https://twitter.com/"><img src="1.png"  ></a>
          <a  href="https://www.facebook.com/"><img src="2.png"  ></a>
          <a  href="https://www.instagram.com/"><img src="3.png"></a>
          <a  href="https://www.youtube.com/"><img src="4.png"></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-light" style="background-color:black">
    <a href="http://localhost/phase2/viewproduct.php">View Product</a>
    <a href="http://localhost/phase2/addproduct.php">Add Product</a>

    <a href ="logout.php" >LOGOUT</a>

  </nav>




<!DOCTYPE html>

<head>
	<title>Bootstrap Example</title>

	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>


<?php

//include('accessControl.php');
if(isset($_POST['submit']))
{
	//var_dump('form submitted');
	//die();
    $conn = mysqli_connect('localhost','root','','products');
	
        
        $prid=$_POST['pid'];
		$prname=$_POST['pname'];
		$prprice=$_POST['pprice'];
        $prcode=$_POST['pcode'];
        $prdiscount=$_POST['pdiscount'];
        $prstock=$_POST['pstock'];
        $prsize=$_POST['psize'];
        $prdetails=$_POST['pdetail'];
        $primg=$_POST['ppicture'];

        $res = "INSERT INTO pd(productName,productPrice,productCode,productInstock,productDiscount,productSizes,productDetails,productId,img) VALUES('$prname','$prprice','$prcode','$prstock','$prdiscount','$prsize','$prdetails','$prid','$primg')";
        mysqli_query($conn,$res);
	
		header('Location: viewproduct.php');
}
?>


	<div class="container">

		<h2>Add New Product</h2><br>
		
		<form action=""  method="POST">
			<div class="form-group">
				<label >Product ID:</label>
				<input type="number" class="form-control" id="pid" placeholder="Enter Product ID" name="pid">
			</div>
			<div class="form-group">
				<label >Product Name:</label>
				<input type="text" class="form-control" id="pname" placeholder="Enter Product Name" name="pname">
			</div>
			<div class="form-group">
				<label >Product Price:</label>
				<input type="number" class="form-control" id="pprice" placeholder="Enter Product price" name="pprice">
			</div>
            <div class="form-group">
				<label >Product Code:</label>
				<input type="text" class="form-control" id="pcode" placeholder="Enter Product code" name="pcode">
			</div>
            <div class="form-group">
				<label >Product Stock(Y/N):</label>
				<input type="boolean" class="form-control" id="pstock" placeholder="Enter Product stock" name="pstock">
			</div>
            <div class="form-group">
				<label >Product Discount:</label>
				<input type="number" class="form-control" id="pdiscount" placeholder="Enter Product discount" name="pdiscount">
			</div>
            <div class="form-group">
				<label >Product Sizes:</label>
				<input type="text"  id="psize" class="form-control" placeholder="Enter Product size" name="psize">
			</div>
            <div class="form-group">
				<label >Product Detail:</label>
				<input type="textbox"  id="pdetail" class="form-control" placeholder="Enter Product details" name="pdetail">
			</div>
            <div class="form-group">
				<label >Product Image:</label>
                <input type="file" id="ppicture" name="ppicture">
			</div>
			<button type="submit" name="submit" class="btn btn-default">Submit</button>
		</form>
	</div>

 <!-- Footer -->
 <footer class="page-footer font-small mdb-color pt-4">

<!-- Footer Links -->
<div class="container text-center text-md-left">

  <!-- Footer links -->
  <div class="row text-center text-md-left mt-3 pb-3">

	<!-- Grid column -->
	<div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
	  <h6 class="text-uppercase mb-4 font-weight-bold">MOBIGIN</h6>
	  <p>Mobigin is the best place where you can buy the best mobile accessories.</p>
	</div>
	<!-- Grid column -->

	<hr class="w-100 clearfix d-md-none">

	<!-- Grid column -->
	<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
	  <h6 class="text-uppercase mb-4 font-weight-bold">Products</h6>
	  <p>
		<a href="#!">Handfrees</a>
	  </p>
	  <p>
		<a href="#!">Chargers</a>
	  </p>
	  <p>
		<a href="#!">Datacables</a>
	  </p>
	  <p>
		<a href="#!">Gaming Remotes</a>
	  </p>
	</div>
	<!-- Grid column -->

	<hr class="w-100 clearfix d-md-none">

	<!-- Grid column -->
	<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
	  <h6 class="text-uppercase mb-4 font-weight-bold">Useful links</h6>
	  <p>
		<a href="#!">Your Account</a>
	  </p>
	  <p>
		<a href="#!">Become an Affiliate</a>
	  </p>
	  <p>
		<a href="#!">Shipping Rates</a>
	  </p>
	  <p>
		<a href="#!">Help</a>
	  </p>
	</div>

	<!-- Grid column -->
	<hr class="w-100 clearfix d-md-none">

	<!-- Grid column -->
	<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
	  <h6 class="text-uppercase mb-4 font-weight-bold">Contact</h6>
	  <p>
		<i class="fas fa-home mr-3"></i>Ghari shahu lahore</p>
	  <p>
		<i class="fas fa-envelope mr-3"></i> buland1261khan@gmail.com</p>
	  <p>
		<i class="fas fa-phone mr-3"></i> +92 314 424 4289</p>
	  <p>
		<i class="fas fa-print mr-3"></i> +92 314 424 4289</p>
	</div>
	<!-- Grid column -->

  </div>
  <!-- Footer links -->

  <hr>

  <!-- Grid row -->
  <div class="row d-flex align-items-center">

	<!-- Grid column -->
	<div class="col-md-7 col-lg-8">

	  <!--Copyright-->
	  <p class="text-center text-md-left">© 2020 Copyright:
		<a href="https://facebook.com/">
		  <strong> facebook
		  </strong>
		</a>
	  </p>

	</div>
	<!-- Grid column -->

	<!-- Grid column -->
	<div class="col-md-5 col-lg-4 ml-lg-0">

	  <!-- Social buttons -->
	  <div class="text-center text-md-right">
		<ul class="list-unstyled list-inline">
		  <li class="list-inline-item">
			<a class="btn-floating btn-sm rgba-white-slight mx-1">
			  <i class="fab fa-facebook-f"></i>
			</a>
		  </li>
		  <li class="list-inline-item">
			<a class="btn-floating btn-sm rgba-white-slight mx-1">
			  <i class="fab fa-twitter"></i>
			</a>
		  </li>
		  <li class="list-inline-item">
			<a class="btn-floating btn-sm rgba-white-slight mx-1">
			  <i class="fab fa-google-plus-g"></i>
			</a>
		  </li>
		  <li class="list-inline-item">
			<a class="btn-floating btn-sm rgba-white-slight mx-1">
			  <i class="fab fa-linkedin-in"></i>
			</a>
		  </li>
		</ul>
	  </div>

	</div>
	<!-- Grid column -->

  </div>
  <!-- Grid row -->

</div>
<!-- Footer Links -->

</footer>
<!-- Footer -->
</body>
</html>
