<html>
<head>
<title>Mobigin</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">



</head>
<body>
<div class="container">
      <div class="row">
        <div class="col-lg-9">
          <a href="http://localhost/phase2/HomePage.php"><img src="logo.png" alt="Logo"></a>
        </div>
        <div class="col-lg-3" style="margin-top: 5%;">
          <a  href="https://twitter.com/"><img src="1.png"  ></a>
          <a  href="https://www.facebook.com/"><img src="2.png"  ></a>
          <a  href="https://www.instagram.com/"><img src="3.png"></a>
          <a  href="https://www.youtube.com/"><img src="4.png"></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-light" style="background-color:black">
    <a href="http://localhost/phase2/HomePage.php">Home</a>
    <a href="http://localhost/phase2/AboutUs.php">About US</a>
    <a href="http://localhost/phase2/Products.php">Products</a>
    <a href="http://localhost/phase2/ContactUs.php">Contact Us</a>


  </nav>
  <h1><center>MOBIGIN</center></h1>
  <h3>Contact Us</h3><br>
<div class="container">
<div class="row">
<div class="col-lg-8">
    <form action="">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" ><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>
        <label for="Phone">Phone:</label>
        <input type="number" id="phone" name="phone" ><br>
        Role:
        <input type="radio" id="techer" name="role" value="techer">
  <label for="techer">Teacher</label>
  <input type="radio" id="student" name="role" value="student">
  <label for="student">Student</label><br>
City:<select>
<option>Lahore</option>
<option>Islamabad</option>
<option>Karachi</option>
<option>Peshwor</option>

</select><br>
Message:
<br>
<textarea col="200" row="100"></textarea>
<br><br><br>


        <input type="submit" value="Submit">
      </form> 
</div>
<div class="col-lg-4">
<div style="border: solid; border-radius: 1px; border-color: black; height: 200px;" >
<pre style="text-align: justify;">
 H # 18 St # 35 
 new abadi ghari
 shahu lahore
</pre>

</div>

<br>
<div id="googleMap"style="border: solid; border-radius: 1px; border-color: black; height: 200px;" >
    
<script>
function myMap() {
var mapProp= {
  center:new google.maps.LatLng(51.508742,-0.120850),
  zoom:5,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>



</div>
</div>
</div>





<!-------------------------------------------Footer----------------------------------------------------->
   
  <!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left mt-3 pb-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">MOBIGIN</h6>
        <p>Mobigin is the best place where you can buy the best mobile accessories.</p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Products</h6>
        <p>
          <a href="#!">Handfrees</a>
        </p>
        <p>
          <a href="#!">Chargers</a>
        </p>
        <p>
          <a href="#!">Datacables</a>
        </p>
        <p>
          <a href="#!">Gaming Remotes</a>
        </p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Useful links</h6>
        <p>
          <a href="#!">Your Account</a>
        </p>
        <p>
          <a href="#!">Become an Affiliate</a>
        </p>
        <p>
          <a href="#!">Shipping Rates</a>
        </p>
        <p>
          <a href="#!">Help</a>
        </p>
      </div>

      <!-- Grid column -->
      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Contact</h6>
        <p>
          <i class="fas fa-home mr-3"></i>Ghari shahu lahore</p>
        <p>
          <i class="fas fa-envelope mr-3"></i> buland1261khan@gmail.com</p>
        <p>
          <i class="fas fa-phone mr-3"></i> +92 314 424 4289</p>
        <p>
          <i class="fas fa-print mr-3"></i> +92 314 424 4289</p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Footer links -->

    <hr>

    <!-- Grid row -->
    <div class="row d-flex align-items-center">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left">© 2020 Copyright:
          <a href="https://facebook.com/">
            <strong> facebook
            </strong>
          </a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->
</body></html>