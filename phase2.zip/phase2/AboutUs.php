<html>
<head>
<title>Mobigin</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">



</head>
<body>
<div class="container">
      <div class="row">
        <div class="col-lg-9">
          <a href="http://localhost/phase2/HomePage.php"><img src="logo.png" alt="Logo"></a>
        </div>
        <div class="col-lg-3" style="margin-top: 5%;">
          <a  href="https://twitter.com/"><img src="1.png"  ></a>
          <a  href="https://www.facebook.com/"><img src="2.png"  ></a>
          <a  href="https://www.instagram.com/"><img src="3.png"></a>
          <a  href="https://www.youtube.com/"><img src="4.png"></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-light" style="background-color:black">
    <a href="http://localhost/phase2/HomePage.php">Home</a>
    <a href="http://localhost/phase2/AboutUs.php">About US</a>
    <a href="http://localhost/phase2/Products.php">Products</a>
    <a href="http://localhost/phase2/ContactUs.php">Contact Us</a>


  </nav>
  <h1><center>MOBIGIN</center></h1>

<h2>
    About our Bussiness
</h2><p style="text-align: justify;">Have you ever heard the free home delivery of your favorite mobile accessory in Pakistan? Now dreams have come true via shoprex.com mobile accessories e-store which showcases numerous types of mobile accessories for your smartphones, tablets and bar phones. Some of the most demanding phone accessories on shoprex.com include mobile chargers, data cable, stylish mobile phone cases and covers, memory cards, power banks, lights and more. Here you can find best prices with quality. In order to save more cost on various accessories, check out bundles and packs at discount prices.
Buy the best price mobile accessories online in Pakistan, Shoprex.com offers the quality mobile accessories on its e-store with free shipping in any location across Pakistan. Now you can purchase guaranteed products for your candy bar phone and smartphone by just sitting at your house. All you need to do is to visit shorex.com online store and explore the large variety of products. Look for your desire mobile accessory and place and order, your desire product will rashly delivered to you in no time.

The entire mobile accessories list consist of most demanding and exciting products with the products bundles and packages which result in saving more cost on shopping via Shoprex.com. The best accessories of 2018 are also listed with its entire details and specifications which can help you more to purchase right accessory for smartphone device. You may also confirm your cell phone models with the product title which makes you ensure that you are shopping for your needed accessory. Let’s have a look on major mobile accessories you find at Shoprex E-store:
</p>
<h3><center>Mobile Phone Covers</center></h3>
<p style="text-align: justify;">Mobile phone covers are the major attraction at shoprex.com accessories sections, there are number of cool smartphone accessories are available in respect of different choices and selection among the people. You may find, cartoon mobile covers, luxury smartphone covers and mobile covers for her for the entire range and models of smartphone and candy bar phones.
Mobile Phone Cables
As all we know, cables are the most essential part of a mobile phone, find the best and divers types of cables for buying at cheap prices for any handset model, there are several connector type are also available in these cable according to different smartphones.
</p>
<h3><center>Lights</center></h3>
<p style="text-align: justify;">Lighten your surrounding with cool looking smartphone and other devices lights which can be use temporary, this is can be useful accessory for travel and power breakdown which use your mobile phone or laptop power. Buy of stuff like this at Shoprex.com with free delivery.
</p><h3><center>Selfi stick</center></h3>
<p style="text-align: justify;">Keep up with the selfie trend all around the globe, in order to fulfill your fond of selfies, we bring your numerous kinds of selfie stick to buy at low prices in Pakistan with free delivery, you may find Bluetooth and without Bluetooth selfie stick with wire.
</p>
    <h3><center>Mobile Phone Chargers</center></h3>
    <p style="text-align: justify;">
Get high quality mobile phone wired or wireless charges. You may buy smartphone chargers for all known phones at best prices in Pakistan with free delivery. These chargers can power up Samsung, Nokia, HTC, iPhones and Huawei smartphone with or without wireless charging capabilities. Choose charger which perfectly matched with your smartphone by reviewing the specifications of that charging adaptor.

You are currently now in category of Accessories with availability of 137 products (one hundred and thirty-seven Accessories products) - updated on Thu 09 Jan, 2020. You may order Accessories all over Pakistan including Karachi, Lahore, Islamabad, Rawalpindi, Peshawar, Quetta, Faisalabad and over 800 cities, towns and villages in Pakistan. This page has been reviewed 15 times as last checked Thu 19 Oct, 2017
</p>

<!-------------------------------------------Footer----------------------------------------------------->
  
  <!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left mt-3 pb-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">MOBIGIN</h6>
        <p>Mobigin is the best place where you can buy the best mobile accessories.</p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Products</h6>
        <p>
          <a href="#!">Handfrees</a>
        </p>
        <p>
          <a href="#!">Chargers</a>
        </p>
        <p>
          <a href="#!">Datacables</a>
        </p>
        <p>
          <a href="#!">Gaming Remotes</a>
        </p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Useful links</h6>
        <p>
          <a href="#!">Your Account</a>
        </p>
        <p>
          <a href="#!">Become an Affiliate</a>
        </p>
        <p>
          <a href="#!">Shipping Rates</a>
        </p>
        <p>
          <a href="#!">Help</a>
        </p>
      </div>

      <!-- Grid column -->
      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Contact</h6>
        <p>
          <i class="fas fa-home mr-3"></i>Ghari shahu lahore</p>
        <p>
          <i class="fas fa-envelope mr-3"></i> buland1261khan@gmail.com</p>
        <p>
          <i class="fas fa-phone mr-3"></i> +92 314 424 4289</p>
        <p>
          <i class="fas fa-print mr-3"></i> +92 314 424 4289</p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Footer links -->

    <hr>

    <!-- Grid row -->
    <div class="row d-flex align-items-center">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left">© 2020 Copyright:
          <a href="https://facebook.com/">
            <strong> facebook
            </strong>
          </a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a class="btn-floating btn-sm rgba-white-slight mx-1">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->
</body></html>